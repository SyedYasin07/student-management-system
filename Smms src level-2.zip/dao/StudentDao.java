package com.pst.smms.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.pst.smms.Bo.StudentBo;
import com.pst.smms.DTO.StudentDto;
import com.pst.smms.Vo.StudentVo;

public class StudentDao {

    private static final String SELECT_ALL_STUDENTS = "SELECT * FROM student";
    private static final String ADD_NEW_STUDENT = "INSERT INTO student VALUES (?, ?, ?, ?, ?, ?, ?)";
    private static final String UPDATE_STUDENT_BY_ROLLNUMBER = 
        "UPDATE student SET full_name=?, gender=?, dob=?, mobile=?, email=?, password=? WHERE roll_number=?";
	
	  private static final String GET_STUDENT_BY_ROLL =
	  "SELECT * FROM student WHERE roll_number=?";
	  private static final String DELETE_MARKS="DELETE FROM student WHERE roll_number = ?";
	  private static final String SEARCH_MARKS="select*from student where roll_number=?";
	 

    // ✅ Fetch all students
    public List<StudentDto> getAllStudents() {
    	  List<StudentDto> list = new ArrayList<StudentDto>(); 
        try {
        	 Class.forName("com.mysql.cj.jdbc.Driver");
             Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/smms", "root", "$yasin4758");

             PreparedStatement ps = con.prepareStatement(SELECT_ALL_STUDENTS);
             ResultSet rs=ps.executeQuery();
           
             while(rs.next()) {
            	 StudentDto dto=new StudentDto(
            			 rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDate(4),rs.getString(5),rs.getString(6),rs.getString(7)
            			 ) ;
            	 list.add(dto);
             }
        }catch(Exception e) {
        	e.printStackTrace();
        }
           return list;
    }

    // ✅ Insert new student
    public int createNewStudent(StudentBo bo) throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/smms", "root", "$yasin4758");
             PreparedStatement ps = con.prepareStatement(ADD_NEW_STUDENT) ;
            		 

            ps.setInt(1, bo.getRollnumber());
            ps.setString(2, bo.getName());
            ps.setString(3, bo.getGender());
            ps.setDate(4, bo.getDob());
            ps.setString(5, bo.getMobile());
            ps.setString(6, bo.getEmail());
            ps.setString(7, bo.getPassword());
            int i=ps.executeUpdate();
            return i;
        }
    

    // ✅ Get student by roll number
    public StudentDto getStudentByRoll(int rollNumber) {
        StudentDto dto = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/smms", "root", "$yasin4758");

            PreparedStatement ps = con.prepareStatement(GET_STUDENT_BY_ROLL);
            ps.setInt(1, rollNumber);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                dto = new StudentDto();
                dto.setRollNumber(rs.getInt("roll_number"));
                dto.setFullName(rs.getString("full_name"));
                dto.setGender(rs.getString("gender"));
                dto.setDateofbirth(rs.getDate("dob"));
                dto.setMobileNumber(rs.getString("mobile"));
                dto.setEmail(rs.getString("email"));
                dto.setPassword(rs.getString("password"));
            }

            rs.close();
            ps.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return dto;
    }
 // StudentDao.java
    public int updateStudent(StudentBo bo) {
        int rows = 0;
        try (
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/smms", "root", "$yasin4758");
            PreparedStatement ps = con.prepareStatement(
                "UPDATE student SET full_name = ?, gender = ?, dob = ?, mobile = ?, email = ?, password = ? WHERE roll_number = ?");
        ) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            ps.setString(1, bo.getName());
            ps.setString(2, bo.getGender());
            ps.setDate(3, bo.getDob());
            ps.setString(4, bo.getMobile());
            ps.setString(5, bo.getEmail());
            ps.setString(6, bo.getPassword());
            ps.setInt(7, bo.getRollnumber());

            rows = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rows;
    }
    public int deleteByRollNumber(int rollNumber) throws Exception {
        int result = 0;
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/smms", "root", "$yasin4758");
        PreparedStatement ps = con.prepareStatement(DELETE_MARKS);
        ps.setInt(1, rollNumber);
        result = ps.executeUpdate();
        return result;
    }
    public StudentDto SearchByRollNumber(int rollNumber) throws Exception {
    	StudentDto dto = null;
        int result = 0;
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/smms", "root", "$yasin4758");
        PreparedStatement ps = con.prepareStatement(SEARCH_MARKS);
        ps.setInt(1, rollNumber);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            dto = new StudentDto();
            dto.setRollNumber(rs.getInt("roll_number"));
            dto.setFullName(rs.getString("full_name"));
            dto.setGender(rs.getString("gender"));
            dto.setDateofbirth(rs.getDate("dob"));
            dto.setMobileNumber(rs.getString("mobile"));
            dto.setEmail(rs.getString("email"));
            dto.setPassword(rs.getString("password"));
        }

        rs.close();
        ps.close();
        con.close();

    
        return dto;
    }

	
}


